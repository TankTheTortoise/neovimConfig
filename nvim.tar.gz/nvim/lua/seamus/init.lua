print("Hello from seamus")

